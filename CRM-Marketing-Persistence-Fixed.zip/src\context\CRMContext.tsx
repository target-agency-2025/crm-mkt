import React, { createContext, useContext, useReducer, useEffect } from 'react';

interface Client {
  id: string;
  name: string;
  email: string;
  phone: string;
  company?: string;
  profilePhoto?: string;
  color: string;
  monthlyValue: number;
  paymentDay: number;
  optionalPaymentDate1?: string;
  optionalPaymentDate2?: string;
  status: 'active' | 'inactive' | 'paused';
  createdAt: string;
}

interface UniqueJob {
  id: string;
  name: string;
  phone: string;
  uniqueValue: number;
  paymentDate: string;
  clientId?: string;
  status: 'active' | 'inactive' | 'completed';
  createdAt: string;
}

interface Invoice {
  id: string;
  clientId?: string;
  uniqueJobId?: string;
  type: 'client' | 'uniqueJob';
  clientName: string;
  description: string;
  amount: number;
  dueDate: string;
  status: 'pending' | 'paid' | 'overdue';
  createdAt: string;
}

interface Credential {
  id: string;
  clientId?: string;
  title: string;
  username: string;
  password: string;
  url?: string;
  notes?: string;
  category: 'general' | 'social' | 'api' | 'password';
  socialPlatform?: string;
  createdAt: string;
}

interface Task {
  id: string;
  title: string;
  description: string;
  status: 'backlog' | 'doing' | 'waiting' | 'done';
  clientId?: string;
  dueDate?: string;
  createdAt: string;
}

interface BudgetPlan {
  id: string;
  name: string;
  description: string;
  price: number;
  features: string[];
  color: string;
  isActive: boolean;
  type: 'starter' | 'premium' | 'completo';
  customizations: {
    posts: number;
    stories: number;
    presentialRecordings: number;
    socialMediaManagement: boolean;
    additionalServices: string[];
  };
  createdAt: string;
}

interface Quote {
  id: string;
  type: 'monthly' | 'unique';
  planName: string;
  planType?: 'plano' | 'servico'; // Optional for backwards compatibility
  clientName: string;
  clientEmail?: string;
  clientPhone?: string;
  clientCompany?: string;
  clientId?: string; // Optional link to existing client
  services: Array<{
    id: string;
    title: string;
    description: string;
  }>;
  gifts?: Array<{
    id: string;
    title: string;
    description: string;
  }>;
  // For monthly plans
  monthlyValue?: number;
  // For unique services
  uniqueValue?: number;
  validUntil: string;
  status: 'draft' | 'sent' | 'approved' | 'rejected' | 'expired';
  notes?: string;
  createdAt: string;
}

interface Budget {
  id: string;
  type: 'monthly' | 'unique';
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  clientCompany?: string;
  // For monthly budgets
  selectedPlans?: string[];
  // For unique budgets
  uniqueService?: {
    title: string;
    description: string;
    deadline: string;
    value: number;
    conditions: string;
  };
  customServices: Array<{
    id: string;
    name: string;
    description: string;
    price: number;
  }>;
  discount: number;
  discountType: 'percentage' | 'fixed';
  validUntil: string;
  status: 'draft' | 'sent' | 'approved' | 'rejected' | 'expired';
  notes?: string;
  createdAt: string;
}

interface CRMState {
  clients: Client[];
  uniqueJobs: UniqueJob[];
  invoices: Invoice[];
  credentials: Credential[];
  tasks: Task[];
  budgetPlans: BudgetPlan[];
  budgets: Budget[];
  quotes: Quote[];
}

type CRMAction = 
  | { type: 'ADD_CLIENT'; payload: Client }
  | { type: 'UPDATE_CLIENT'; payload: Client }
  | { type: 'DELETE_CLIENT'; payload: string }
  | { type: 'ADD_UNIQUE_JOB'; payload: UniqueJob }
  | { type: 'UPDATE_UNIQUE_JOB'; payload: UniqueJob }
  | { type: 'DELETE_UNIQUE_JOB'; payload: string }
  | { type: 'ADD_INVOICE'; payload: Invoice }
  | { type: 'UPDATE_INVOICE'; payload: Invoice }
  | { type: 'DELETE_INVOICE'; payload: string }
  | { type: 'ADD_CREDENTIAL'; payload: Credential }
  | { type: 'UPDATE_CREDENTIAL'; payload: Credential }
  | { type: 'DELETE_CREDENTIAL'; payload: string }
  | { type: 'ADD_TASK'; payload: Task }
  | { type: 'UPDATE_TASK'; payload: Task }
  | { type: 'DELETE_TASK'; payload: string }
  | { type: 'ADD_BUDGET_PLAN'; payload: BudgetPlan }
  | { type: 'UPDATE_BUDGET_PLAN'; payload: BudgetPlan }
  | { type: 'DELETE_BUDGET_PLAN'; payload: string }
  | { type: 'ADD_BUDGET'; payload: Budget }
  | { type: 'UPDATE_BUDGET'; payload: Budget }
  | { type: 'DELETE_BUDGET'; payload: string }
  | { type: 'ADD_QUOTE'; payload: Quote }
  | { type: 'UPDATE_QUOTE'; payload: Quote }
  | { type: 'DELETE_QUOTE'; payload: string }
  | { type: 'GENERATE_CLIENT_INVOICES' }
  | { type: 'LOAD_STATE'; payload: CRMState };

const initialState: CRMState = {
  clients: [],
  uniqueJobs: [],
  invoices: [],
  credentials: [],
  tasks: [],
  budgetPlans: [
    {
      id: 'starter-plan',
      name: 'Starter',
      description: 'Plano básico para pequenas empresas',
      price: 800,
      features: [
        'Gestão de redes sociais',
        'Posts personalizados',
        'Stories criativos',
        'Relatórios mensais'
      ],
      color: '#10B981',
      isActive: true,
      type: 'starter',
      customizations: {
        posts: 12,
        stories: 8,
        presentialRecordings: 0,
        socialMediaManagement: true,
        additionalServices: []
      },
      createdAt: new Date().toISOString()
    },
    {
      id: 'premium-plan',
      name: 'Premium',
      description: 'Plano intermediário com mais recursos',
      price: 1500,
      features: [
        'Tudo do plano Starter',
        'Mais posts e stories',
        'Gravações presenciais',
        'Campanhas pagas',
        'Suporte prioritário'
      ],
      color: '#8B5CF6',
      isActive: true,
      type: 'premium',
      customizations: {
        posts: 20,
        stories: 15,
        presentialRecordings: 2,
        socialMediaManagement: true,
        additionalServices: ['Campanhas pagas']
      },
      createdAt: new Date().toISOString()
    },
    {
      id: 'completo-plan',
      name: 'Completo',
      description: 'Plano avançado com todos os recursos',
      price: 2500,
      features: [
        'Tudo dos planos anteriores',
        'Posts e stories ilimitados',
        'Gravações presenciais frequentes',
        'Gestão completa de campanhas',
        'Consultoria estratégica',
        'Relatórios detalhados'
      ],
      color: '#F59E0B',
      isActive: true,
      type: 'completo',
      customizations: {
        posts: 30,
        stories: 25,
        presentialRecordings: 4,
        socialMediaManagement: true,
        additionalServices: ['Campanhas pagas', 'Consultoria estratégica', 'Relatórios detalhados']
      },
      createdAt: new Date().toISOString()
    }
  ],
  budgets: [],
  quotes: []
};

const crmReducer = (state: CRMState, action: CRMAction): CRMState => {
  switch (action.type) {
    case 'ADD_CLIENT':
      return { ...state, clients: [...state.clients, action.payload] };
    case 'UPDATE_CLIENT':
      return {
        ...state,
        clients: state.clients.map(client =>
          client.id === action.payload.id ? action.payload : client
        )
      };
    case 'DELETE_CLIENT':
      return {
        ...state,
        clients: state.clients.filter(client => client.id !== action.payload)
      };
    case 'GENERATE_CLIENT_INVOICES': {
      const currentDate = new Date();
      const currentMonth = currentDate.getMonth();
      const currentYear = currentDate.getFullYear();
      const currentDay = currentDate.getDate();
      
      const newInvoices: Invoice[] = [];
      
      // Generate invoices for active clients whose payment day matches today
      state.clients
        .filter(client => 
          client.status === 'active' && 
          client.monthlyValue > 0 && 
          client.paymentDay === currentDay
        )
        .forEach(client => {
          // Check if invoice for this month already exists
          const existingInvoice = state.invoices.find(invoice => 
            invoice.clientId === client.id &&
            invoice.type === 'client' &&
            new Date(invoice.createdAt).getMonth() === currentMonth &&
            new Date(invoice.createdAt).getFullYear() === currentYear
          );
          
          if (!existingInvoice) {
            const invoiceId = `${Date.now()}-${client.id}`;
            const monthNames = [
              'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
              'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
            ];
            
            const newInvoice: Invoice = {
              id: invoiceId,
              clientId: client.id,
              type: 'client',
              clientName: client.company || client.name,
              description: `Serviços de Marketing - ${monthNames[currentMonth]} ${currentYear}`,
              amount: client.monthlyValue,
              dueDate: new Date(currentYear, currentMonth, client.paymentDay).toISOString().split('T')[0],
              status: 'pending',
              createdAt: new Date().toISOString()
            };
            
            newInvoices.push(newInvoice);
          }
        });
      
      // Also check for optional payment dates
      state.clients
        .filter(client => client.status === 'active' && client.monthlyValue > 0)
        .forEach(client => {
          const checkOptionalDate = (optionalDate?: string) => {
            if (!optionalDate) return;
            
            const optionalPaymentDate = new Date(optionalDate);
            if (
              optionalPaymentDate.getDate() === currentDay &&
              optionalPaymentDate.getMonth() === currentMonth &&
              optionalPaymentDate.getFullYear() === currentYear
            ) {
              // Check if invoice for this optional date already exists
              const existingOptionalInvoice = state.invoices.find(invoice => 
                invoice.clientId === client.id &&
                invoice.type === 'client' &&
                invoice.dueDate === optionalDate
              );
              
              if (!existingOptionalInvoice) {
                const invoiceId = `${Date.now()}-opt-${client.id}`;
                const monthNames = [
                  'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
                  'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
                ];
                
                const newInvoice: Invoice = {
                  id: invoiceId,
                  clientId: client.id,
                  type: 'client',
                  clientName: client.company || client.name,
                  description: `Serviços de Marketing - ${monthNames[currentMonth]} ${currentYear} (Data Opcional)`,
                  amount: client.monthlyValue,
                  dueDate: optionalDate,
                  status: 'pending',
                  createdAt: new Date().toISOString()
                };
                
                newInvoices.push(newInvoice);
              }
            }
          };
          
          checkOptionalDate(client.optionalPaymentDate1);
          checkOptionalDate(client.optionalPaymentDate2);
        });
      
      return {
        ...state,
        invoices: [...state.invoices, ...newInvoices]
      };
    }
    case 'ADD_UNIQUE_JOB':
      return { ...state, uniqueJobs: [...state.uniqueJobs, action.payload] };
    case 'UPDATE_UNIQUE_JOB':
      return {
        ...state,
        uniqueJobs: state.uniqueJobs.map(job =>
          job.id === action.payload.id ? action.payload : job
        )
      };
    case 'DELETE_UNIQUE_JOB':
      return {
        ...state,
        uniqueJobs: state.uniqueJobs.filter(job => job.id !== action.payload)
      };
    case 'ADD_INVOICE':
      return { ...state, invoices: [...state.invoices, action.payload] };
    case 'UPDATE_INVOICE':
      return {
        ...state,
        invoices: state.invoices.map(invoice =>
          invoice.id === action.payload.id ? action.payload : invoice
        )
      };
    case 'DELETE_INVOICE':
      return {
        ...state,
        invoices: state.invoices.filter(invoice => invoice.id !== action.payload)
      };
    case 'ADD_CREDENTIAL':
      return { ...state, credentials: [...state.credentials, action.payload] };
    case 'UPDATE_CREDENTIAL':
      return {
        ...state,
        credentials: state.credentials.map(cred =>
          cred.id === action.payload.id ? action.payload : cred
        )
      };
    case 'DELETE_CREDENTIAL':
      return {
        ...state,
        credentials: state.credentials.filter(cred => cred.id !== action.payload)
      };
    case 'ADD_TASK':
      return { ...state, tasks: [...state.tasks, action.payload] };
    case 'UPDATE_TASK':
      return {
        ...state,
        tasks: state.tasks.map(task =>
          task.id === action.payload.id ? action.payload : task
        )
      };
    case 'DELETE_TASK':
      return {
        ...state,
        tasks: state.tasks.filter(task => task.id !== action.payload)
      };
    case 'ADD_BUDGET_PLAN':
      return { ...state, budgetPlans: [...state.budgetPlans, action.payload] };
    case 'UPDATE_BUDGET_PLAN':
      return {
        ...state,
        budgetPlans: state.budgetPlans.map(plan =>
          plan.id === action.payload.id ? action.payload : plan
        )
      };
    case 'DELETE_BUDGET_PLAN':
      return {
        ...state,
        budgetPlans: state.budgetPlans.filter(plan => plan.id !== action.payload)
      };
    case 'ADD_BUDGET':
      return { ...state, budgets: [...state.budgets, action.payload] };
    case 'UPDATE_BUDGET':
      return {
        ...state,
        budgets: state.budgets.map(budget =>
          budget.id === action.payload.id ? action.payload : budget
        )
      };
    case 'DELETE_BUDGET':
      return {
        ...state,
        budgets: state.budgets.filter(budget => budget.id !== action.payload)
      };
    case 'ADD_QUOTE':
      return { ...state, quotes: [...state.quotes, action.payload] };
    case 'UPDATE_QUOTE':
      return {
        ...state,
        quotes: state.quotes.map(quote =>
          quote.id === action.payload.id ? action.payload : quote
        )
      };
    case 'DELETE_QUOTE':
      return {
        ...state,
        quotes: state.quotes.filter(quote => quote.id !== action.payload)
      };
    case 'LOAD_STATE':
      return action.payload;
    default:
      return state;
  }
};

const CRMContext = createContext<{
  state: CRMState;
  dispatch: React.Dispatch<CRMAction>;
} | null>(null);

export const CRMProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(crmReducer, initialState);

  useEffect(() => {
    const saved = localStorage.getItem('crm-data');
    if (saved) {
      try {
        const parsedState = JSON.parse(saved);
        // Mesclar com planos padrão se não existirem
        const stateWithDefaults = {
          ...parsedState,
          budgetPlans: parsedState.budgetPlans && parsedState.budgetPlans.length > 0 
            ? parsedState.budgetPlans 
            : initialState.budgetPlans,
          quotes: parsedState.quotes || []
        };
        dispatch({ type: 'LOAD_STATE', payload: stateWithDefaults });
        
        // Generate invoices automatically when app loads
        setTimeout(() => {
          dispatch({ type: 'GENERATE_CLIENT_INVOICES' });
        }, 1000);
      } catch (error) {
        console.error('Error loading saved data:', error);
        // Se houver erro, usar estado inicial
        dispatch({ type: 'LOAD_STATE', payload: initialState });
      }
    } else {
      // Se não houver dados salvos, usar estado inicial
      dispatch({ type: 'LOAD_STATE', payload: initialState });
    }
  }, []);

  // Check for invoice generation daily
  useEffect(() => {
    const checkInvoices = () => {
      dispatch({ type: 'GENERATE_CLIENT_INVOICES' });
    };
    
    // Check immediately and then every hour
    const interval = setInterval(checkInvoices, 60 * 60 * 1000); // Every hour
    
    return () => clearInterval(interval);
  }, [state.clients]); // Re-run when clients change

  useEffect(() => {
    // Salvar apenas se o estado não estiver vazio
    if (state.clients.length > 0 || state.uniqueJobs.length > 0 || state.invoices.length > 0 || 
        state.credentials.length > 0 || state.tasks.length > 0 || state.budgets.length > 0 || state.quotes.length > 0) {
      localStorage.setItem('crm-data', JSON.stringify(state));
    } else {
      // Salvar mesmo se vazio, mas manter os planos padrão
      const stateToSave = {
        ...state,
        budgetPlans: state.budgetPlans.length > 0 ? state.budgetPlans : initialState.budgetPlans
      };
      localStorage.setItem('crm-data', JSON.stringify(stateToSave));
    }
  }, [state]);

  return (
    <CRMContext.Provider value={{ state, dispatch }}>
      {children}
    </CRMContext.Provider>
  );
};

export const useCRM = () => {
  const context = useContext(CRMContext);
  if (!context) {
    throw new Error('useCRM must be used within a CRMProvider');
  }
  
  const { state, dispatch } = context;
  
  return {
    // State
    clients: state.clients,
    uniqueJobs: state.uniqueJobs,
    invoices: state.invoices,
    credentials: state.credentials,
    tasks: state.tasks,
    budgetPlans: state.budgetPlans,
    budgets: state.budgets,
    quotes: state.quotes,
    
    // Actions
    addClient: (client: Omit<Client, 'id' | 'createdAt'>) => {
      const newClient = {
        ...client,
        id: Date.now().toString(),
        createdAt: new Date().toISOString()
      };
      
      dispatch({
        type: 'ADD_CLIENT',
        payload: newClient
      });
      
      // Automatically generate invoice for next month when client is registered
      if (newClient.monthlyValue > 0 && newClient.paymentDay > 0) {
        const nextMonth = new Date();
        nextMonth.setMonth(nextMonth.getMonth() + 1);
        
        const monthNames = [
          'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
          'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
        ];
        
        const invoiceData = {
          type: 'client' as const,
          clientId: newClient.id,
          clientName: newClient.company || newClient.name,
          description: `Serviços de Marketing - ${monthNames[nextMonth.getMonth()]} ${nextMonth.getFullYear()}`,
          amount: newClient.monthlyValue,
          dueDate: new Date(nextMonth.getFullYear(), nextMonth.getMonth(), newClient.paymentDay).toISOString().split('T')[0],
          status: 'pending' as const
        };
        
        dispatch({
          type: 'ADD_INVOICE',
          payload: {
            ...invoiceData,
            id: (Date.now() + 1).toString(),
            createdAt: new Date().toISOString()
          }
        });
      }
    },
    updateClient: (client: Client) => {
      dispatch({ type: 'UPDATE_CLIENT', payload: client });
    },
    deleteClient: (id: string) => {
      dispatch({ type: 'DELETE_CLIENT', payload: id });
    },
    
    addUniqueJob: (job: Omit<UniqueJob, 'id' | 'createdAt'>) => {
      const newJob = {
        ...job,
        id: Date.now().toString(),
        createdAt: new Date().toISOString()
      };
      
      dispatch({
        type: 'ADD_UNIQUE_JOB',
        payload: newJob
      });
      
      // Automatically generate invoice for unique job
      const invoiceData = {
        type: 'uniqueJob' as const,
        uniqueJobId: newJob.id,
        clientName: job.clientId ? 
          state.clients.find(c => c.id === job.clientId)?.name || job.name : 
          job.name,
        description: `Trabalho Único - ${job.name}`,
        amount: job.uniqueValue,
        dueDate: job.paymentDate,
        status: 'pending' as const
      };
      
      dispatch({
        type: 'ADD_INVOICE',
        payload: {
          ...invoiceData,
          id: (Date.now() + 1).toString(),
          createdAt: new Date().toISOString()
        }
      });
    },
    updateUniqueJob: (job: UniqueJob) => {
      dispatch({ type: 'UPDATE_UNIQUE_JOB', payload: job });
    },
    deleteUniqueJob: (id: string) => {
      dispatch({ type: 'DELETE_UNIQUE_JOB', payload: id });
    },
    
    addInvoice: (invoice: Omit<Invoice, 'id' | 'createdAt'>) => {
      dispatch({
        type: 'ADD_INVOICE',
        payload: {
          ...invoice,
          id: Date.now().toString(),
          createdAt: new Date().toISOString()
        }
      });
    },
    updateInvoice: (invoice: Invoice) => {
      const currentInvoice = state.invoices.find(inv => inv.id === invoice.id);
      
      dispatch({ type: 'UPDATE_INVOICE', payload: invoice });
      
      // If invoice status changed from non-paid to paid, generate next month's invoice
      if (currentInvoice && 
          currentInvoice.status !== 'paid' && 
          invoice.status === 'paid' && 
          invoice.type === 'client' && 
          invoice.clientId) {
        
        const client = state.clients.find(c => c.id === invoice.clientId);
        if (client && client.status === 'active' && client.monthlyValue > 0) {
          const currentDueDate = new Date(invoice.dueDate);
          const nextMonth = new Date(currentDueDate);
          nextMonth.setMonth(nextMonth.getMonth() + 1);
          
          // Check if next month's invoice already exists
          const existingNextInvoice = state.invoices.find(inv => 
            inv.clientId === client.id &&
            inv.type === 'client' &&
            new Date(inv.dueDate).getMonth() === nextMonth.getMonth() &&
            new Date(inv.dueDate).getFullYear() === nextMonth.getFullYear()
          );
          
          if (!existingNextInvoice) {
            const monthNames = [
              'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
              'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
            ];
            
            const nextInvoiceData = {
              type: 'client' as const,
              clientId: client.id,
              clientName: client.company || client.name,
              description: `Serviços de Marketing - ${monthNames[nextMonth.getMonth()]} ${nextMonth.getFullYear()}`,
              amount: client.monthlyValue,
              dueDate: new Date(nextMonth.getFullYear(), nextMonth.getMonth(), client.paymentDay).toISOString().split('T')[0],
              status: 'pending' as const
            };
            
            dispatch({
              type: 'ADD_INVOICE',
              payload: {
                ...nextInvoiceData,
                id: `${Date.now()}-next-${client.id}`,
                createdAt: new Date().toISOString()
              }
            });
          }
        }
      }
    },
    deleteInvoice: (id: string) => {
      dispatch({ type: 'DELETE_INVOICE', payload: id });
    },
    
    addCredential: (credential: Omit<Credential, 'id' | 'createdAt'>) => {
      dispatch({
        type: 'ADD_CREDENTIAL',
        payload: {
          ...credential,
          id: Date.now().toString(),
          createdAt: new Date().toISOString()
        }
      });
    },
    updateCredential: (credential: Credential) => {
      dispatch({ type: 'UPDATE_CREDENTIAL', payload: credential });
    },
    deleteCredential: (id: string) => {
      dispatch({ type: 'DELETE_CREDENTIAL', payload: id });
    },
    
    addTask: (task: Omit<Task, 'id' | 'createdAt'>) => {
      dispatch({
        type: 'ADD_TASK',
        payload: {
          ...task,
          id: Date.now().toString(),
          createdAt: new Date().toISOString()
        }
      });
    },
    updateTask: (task: Task) => {
      dispatch({ type: 'UPDATE_TASK', payload: task });
    },
    deleteTask: (id: string) => {
      dispatch({ type: 'DELETE_TASK', payload: id });
    },
    
    addBudgetPlan: (plan: Omit<BudgetPlan, 'id' | 'createdAt'>) => {
      dispatch({
        type: 'ADD_BUDGET_PLAN',
        payload: {
          ...plan,
          id: Date.now().toString(),
          createdAt: new Date().toISOString()
        }
      });
    },
    updateBudgetPlan: (plan: BudgetPlan) => {
      dispatch({ type: 'UPDATE_BUDGET_PLAN', payload: plan });
    },
    deleteBudgetPlan: (id: string) => {
      dispatch({ type: 'DELETE_BUDGET_PLAN', payload: id });
    },
    
    addBudget: (budget: Omit<Budget, 'id' | 'createdAt'>) => {
      dispatch({
        type: 'ADD_BUDGET',
        payload: {
          ...budget,
          id: Date.now().toString(),
          createdAt: new Date().toISOString()
        }
      });
    },
    updateBudget: (budget: Budget) => {
      dispatch({ type: 'UPDATE_BUDGET', payload: budget });
    },
    deleteBudget: (id: string) => {
      dispatch({ type: 'DELETE_BUDGET', payload: id });
    },
    
    addQuote: (quote: Omit<Quote, 'id' | 'createdAt'>) => {
      dispatch({
        type: 'ADD_QUOTE',
        payload: {
          ...quote,
          id: Date.now().toString(),
          createdAt: new Date().toISOString()
        }
      });
    },
    updateQuote: (quote: Quote) => {
      dispatch({ type: 'UPDATE_QUOTE', payload: quote });
    },
    deleteQuote: (id: string) => {
      dispatch({ type: 'DELETE_QUOTE', payload: id });
    },
    
    // Generate invoices for clients based on payment dates
    generateClientInvoices: () => {
      dispatch({ type: 'GENERATE_CLIENT_INVOICES' });
    }
  };
};

export type { Client, UniqueJob, Invoice, Credential, Task, BudgetPlan, Budget, Quote };